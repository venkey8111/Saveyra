<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'saveyra' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ypWbJz8w>9NW`3F=pPlI@FRt6;Ih#|32|@H I2Su~4*&JJ}Y+9TN~z+,m3q 8pmP' );
define( 'SECURE_AUTH_KEY',  'pNNDo!yjA35qc.7R=TywY&B1^WV.M>v/k)SfX=0.YQbu $n;H/*{=vVxxeEuxpHE' );
define( 'LOGGED_IN_KEY',    'iZC1M@,4)~|khHBUttJ@XLEe5:wKb8aB3 Ek.7f,,*[WYPTG+K}5xV5i5JTHSaG4' );
define( 'NONCE_KEY',        'RM2,3n:.Ns<M8tm~!s-Ci9/|z699+1@Di;SCD!6SLfIg)-E>$NI_1}Oe$# cP!u-' );
define( 'AUTH_SALT',        '@jU:TU3]4|w46xF*DPOcHC%I]S9^8x,I613]u=3_dVZz(zG*Erag|Tm|{(o1DFE7' );
define( 'SECURE_AUTH_SALT', '_fSd6_>9TNVHM5J`0#bt~XZ5]PVnlcA-5g^qeWW`Sq#Luf8.h}bp.Pb  (W)x+DM' );
define( 'LOGGED_IN_SALT',   'l6sa|YyL^CLA0da=/,3p$s%0oAwyw)a)Lt@~%kwOdjlvzE0B8-~nx|6={lBviRHX' );
define( 'NONCE_SALT',       '9F$XuN@juB7x,(#BRG:3bcJ~SG,gr2Caj*^,E4hLUKkZj!GEaQ`o4`/}M<TwJ#(D' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
